package com.capgemini.tcc.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Patient {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
