package com.cg.dao;

import com.cg.bean.Hbean;

public interface IHdao {
	String addPatientdetails(Hbean patient) throws Exception;
	Hbean getPatientDetails(String patientId) throws Exception;

}
