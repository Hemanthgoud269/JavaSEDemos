package com.cg.service;

import com.cg.bean.Hbean;

public interface IHservice {
	String addPatientdetails(Hbean patient) throws Exception;
	Hbean getPatientDetails(String patientID) throws Exception;
		

}
