package com.capgemini.lesson11;

import java.util.*;

class HashSetDemo {
	public static void main(String args[]) {
		// create a hash set
		Set hs = new HashSet();
		// add elements to the hash set
		hs.add("1");
		hs.add("A");
		hs.add("D");
		hs.add("null");
		hs.add("C");
		hs.add("A");
		System.out.println(hs);
	}
}
